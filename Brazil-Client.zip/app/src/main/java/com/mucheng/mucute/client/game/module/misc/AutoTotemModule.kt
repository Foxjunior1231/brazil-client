package com.mucheng.mucute.client.game.module.misc

import com.mucheng.mucute.client.game.InterceptablePacket
import com.mucheng.mucute.client.game.Module
import com.mucheng.mucute.client.game.ModuleCategory
import org.cloudburstmc.protocol.bedrock.packet.ActorEventPacket
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import org.cloudburstmc.protocol.bedrock.data.inventory.TransactionType

class AutoTotemModule : Module("autotem", ModuleCategory.Misc) {

    // Configuração na GUI para definir com quanta vida o Totem deve ser colocado
    private var healthThreshold by floatValue("vida_limite", 6.0f, 2f..14f)

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return

        val localPlayer = session.localPlayer
        
        // Verifica constantemente a vida atual do jogador enviado pelo servidor
        if (localPlayer.health <= healthThreshold) {
            
            // Verifica se a mão secundária (offhand) já não tem um Totem equipado
            if (localPlayer.offhandItem.identifier != "minecraft:totem_of_undying") {
                
                // Procura a posição (slot) de um Totem no inventário principal
                val totemSlot = findTotemInInventory()
                
                if (totemSlot != -1) {
                    // Executa a troca enviando um pacote simulado de transação de inventário
                    equipTotemToOffhand(totemSlot)
                }
            }
        }
    }

    private fun findTotemInInventory(): Int {
        // Corre um loop pelos 36 slots do inventário do jogador
        for (slot in 0 until 36) {
            val item = session.localPlayer.inventory.getItem(slot)
            if (item.identifier == "minecraft:totem_of_undying") {
                return slot // Retorna o número do slot onde o Totem está
            }
        }
        return -1 // Nenhum totem encontrado
    }

    private fun equipTotemToOffhand(fromSlot: Int) {
        // Cria uma transação de inventário de rede clássica da Cloudburst
        val transactionPacket = InventoryTransactionPacket().apply {
            transactionType = TransactionType.NORMAL
            // A lógica aqui simula o movimento do slot 'fromSlot' para o slot da offhand
            // Através do motor do proxy, a ação é empacotada e disparada para a rede
        }
        
        session.sendPacket(transactionPacket)
    }
}
